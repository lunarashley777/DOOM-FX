int DisMount(struct DeviceList *volume);
struct DeviceList *Mount(char *name, struct MsgPort *port);
